import { useState } from 'react';
import { cells } from './data/cells';

export default function App() {
  const [selectedId, setSelectedId] = useState<string>(cells[0]?.id ?? '');
  const selectedCell = cells.find((c) => c.id === selectedId) ?? cells[0];
  if (!selectedCell) return <div>No cells data</div>;

  return (
    <div className="h-screen w-screen grid grid-rows-[auto_1fr] overflow-hidden">
      {/* Header */}
      <header className="h-14 flex items-center justify-between px-6 border-b border-paperDark bg-paper/80 backdrop-blur">
        <div className="flex items-baseline gap-3">
          <span className="font-serif text-xl font-semibold text-accent">Cell Architecture Studio</span>
          <span className="text-sm text-ink/60">Explore life at the microscopic level</span>
        </div>
        <nav className="flex gap-4 text-sm text-ink/30 pointer-events-none select-none">
          <span>Gallery</span><span>Library</span><span>Notebooks</span><span>Settings</span>
        </nav>
      </header>

      {/* Main 4-pane grid */}
      <main className="grid grid-cols-[260px_1fr_320px] grid-rows-[1fr_260px] gap-3 p-3 min-h-0">
        {/* Left: cell list */}
        <aside className="row-span-2 bg-white/70 rounded-xl p-3 border border-paperDark overflow-y-auto">
          <div className="text-xs font-semibold text-ink/50 tracking-wider mb-2">CELL TYPES</div>
          <ul className="space-y-1">
            {cells.map((c) => {
              const active = c.id === selectedId;
              return (
                <li key={c.id}>
                  <button
                    onClick={() => setSelectedId(c.id)}
                    className={`w-full text-left px-3 py-2 rounded-lg transition ${
                      active ? 'bg-accent-soft border border-accent/30' : 'hover:bg-paperDark/60'
                    }`}
                  >
                    <div className="text-sm font-medium">{c.nameZh}</div>
                    <div className="text-xs text-ink/50">
                      {c.kingdom === 'eukaryote' ? '真核细胞' : '原核细胞'}
                    </div>
                  </button>
                </li>
              );
            })}
          </ul>
        </aside>

        {/* Center: 3D viewer placeholder */}
        <section className="bg-white/70 rounded-xl border border-paperDark flex flex-col min-h-0">
          <div className="p-4 border-b border-paperDark">
            <div className="font-serif text-2xl font-semibold">{selectedCell.nameEn}</div>
            <div className="text-sm text-ink/60 italic">{selectedCell.nameZh} · {selectedCell.tagline}</div>
          </div>
          <div className="flex-1 flex items-center justify-center text-ink/30 text-sm">
            [3D viewer placeholder — Phase 3]
          </div>
        </section>

        {/* Right: organelle details */}
        <aside className="bg-white/70 rounded-xl p-4 border border-paperDark overflow-y-auto">
          <div className="text-xs font-semibold text-ink/50 tracking-wider mb-2">ORGANELLES</div>
          <ul className="space-y-2">
            {selectedCell.organelles.map((o) => (
              <li key={o.id} className="p-2 rounded-lg hover:bg-paperDark/60 cursor-pointer">
                <div className="text-sm font-medium">{o.nameZh}</div>
                <div className="text-xs text-ink/60">{o.tagline}</div>
              </li>
            ))}
          </ul>
        </aside>

        {/* Bottom: microscope + compare row */}
        <footer className="col-span-2 bg-white/70 rounded-xl p-4 border border-paperDark flex gap-4 items-center text-sm text-ink/50">
          <div className="flex-1">[Microscope view — Phase 5]</div>
          <div className="w-px self-stretch bg-paperDark" />
          <div className="flex-1">[Compare cells — Phase 5]</div>
        </footer>
      </main>
    </div>
  );
}
